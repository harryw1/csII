#include "Delivery.h"

Delivery::Delivery()
{
    this->sender_name = "";
    this->timestamp = "";
}

Delivery::Delivery(string a_Name, string a_Timestamp)
{
    this->sender_name = a_Name;
    this->timestamp = a_Timestamp;
}

void Delivery::print_info()
{
    return;
}